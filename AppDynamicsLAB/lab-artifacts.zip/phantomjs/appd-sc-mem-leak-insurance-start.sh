#!/bin/bash


phantomjs --proxy-type=none appd-sc-mem-leak-insurance-start.js
sleep 1s
