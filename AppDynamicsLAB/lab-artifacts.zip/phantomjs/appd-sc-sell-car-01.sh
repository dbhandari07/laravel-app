#!/bin/bash

while true
do
    phantomjs --proxy-type=none appd-sc-sell-car-01.js	
    sleep 6s
    phantomjs --proxy-type=none appd-sc-sell-car-01.js  
    sleep 6s
    phantomjs --proxy-type=none appd-sc-sell-car-01.js  
    sleep 6s
    phantomjs --proxy-type=none appd-sc-sell-car-01.js  
    sleep 6s
    phantomjs --proxy-type=none appd-sc-sell-car-01.js  
    sleep 6s
    phantomjs --proxy-type=none appd-sc-sell-car-01.js  
    sleep 6s
    phantomjs --proxy-type=none appd-sc-sell-car-01.js  
    sleep 6s
    phantomjs --proxy-type=none appd-sc-sell-car-01.js  
    sleep 6s

done